#!/usr/bin/env python3
"""
Script kiểm tra trạng thái GPIO pins cho hệ thống IoT kiểm soát mực nước
GPIO23 -> Van điện tử (IN1/NO1)
GPIO24 -> Bơm (IN2/NO2)
GPIO17 -> ECHO (cảm biến siêu âm)
GPIO27 -> TRIG (cảm biến siêu âm)
"""

import RPi.GPIO as GPIO
import sys

# Định nghĩa các chân GPIO
PINS = {
    23: "Van điện tử (IN1/NO1)",
    24: "Bơm (IN2/NO2)",
    17: "ECHO - Cảm biến siêu âm",
    27: "TRIG - Cảm biến siêu âm"
}

def check_gpio_status():
    """Kiểm tra trạng thái các chân GPIO"""
    print("=" * 60)
    print("KIỂM TRA TRẠNG THÁI GPIO PINS")
    print("=" * 60)

    # Sử dụng chế độ BCM (Broadcom pin numbering)
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)

    print("\nCác chân GPIO đang được sử dụng:\n")

    for pin, description in PINS.items():
        try:
            # Kiểm tra chân có đang được sử dụng không
            function = GPIO.gpio_function(pin)

            # Giải mã function code
            function_names = {
                GPIO.IN: "INPUT",
                GPIO.OUT: "OUTPUT",
                -1: "CHƯA CẤU HÌNH"
            }

            function_name = function_names.get(function, f"UNKNOWN ({function})")

            # Nếu chân đã được cấu hình, đọc trạng thái
            if function in [GPIO.IN, GPIO.OUT]:
                try:
                    state = GPIO.input(pin)
                    state_str = "HIGH (1)" if state else "LOW (0)"
                    print(f"GPIO{pin:2d} | {function_name:15s} | {state_str:12s} | {description}")
                except:
                    print(f"GPIO{pin:2d} | {function_name:15s} | {'N/A':12s} | {description}")
            else:
                print(f"GPIO{pin:2d} | {function_name:15s} | {'N/A':12s} | {description}")

        except Exception as e:
            print(f"GPIO{pin:2d} | LỖI: {str(e)}")

    print("\n" + "=" * 60)
    print("\nGHI CHÚ:")
    print("- INPUT: Chân được cấu hình làm đầu vào")
    print("- OUTPUT: Chân được cấu hình làm đầu ra")
    print("- HIGH (1): Mức điện áp cao (3.3V)")
    print("- LOW (0): Mức điện áp thấp (0V)")
    print("\nĐối với relay (GPIO23, GPIO24):")
    print("  LOW (0) = Relay BẬT (kích hoạt van/bơm)")
    print("  HIGH (1) = Relay TẮT (ngắt van/bơm)")
    print("=" * 60)

def check_all_gpio():
    """Kiểm tra tất cả GPIO pins đang hoạt động trên hệ thống"""
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)

    print("\n" + "=" * 60)
    print("QUÉT TẤT CẢ GPIO PINS ĐANG HOẠT ĐỘNG")
    print("=" * 60 + "\n")

    active_pins = []
    for pin in range(2, 28):  # GPIO 2-27 là các pin thường dùng
        try:
            function = GPIO.gpio_function(pin)
            if function in [GPIO.IN, GPIO.OUT]:
                active_pins.append(pin)
                function_name = "INPUT" if function == GPIO.IN else "OUTPUT"
                try:
                    state = GPIO.input(pin)
                    state_str = "HIGH" if state else "LOW"
                    marker = " <-- ĐANG DÙNG" if pin in PINS else ""
                    print(f"GPIO{pin:2d} | {function_name:6s} | {state_str:4s}{marker}")
                except:
                    pass
        except:
            pass

    if not active_pins:
        print("Không tìm thấy GPIO nào đang được sử dụng.")

    print("\n" + "=" * 60)

if __name__ == "__main__":
    try:
        check_gpio_status()

        # Hỏi có muốn quét toàn bộ không
        if len(sys.argv) > 1 and sys.argv[1] == "--all":
            check_all_gpio()
        else:
            print("\nSử dụng: python3 check_gpio.py --all để quét toàn bộ GPIO")

    except KeyboardInterrupt:
        print("\n\nĐã dừng bởi người dùng.")
    except Exception as e:
        print(f"\nLỗi: {str(e)}")
        print("Đảm bảo script chạy với quyền sudo: sudo python3 check_gpio.py")
    finally:
        # Không cleanup để giữ nguyên cấu hình hiện tại
        pass
