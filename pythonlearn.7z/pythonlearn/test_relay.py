#!/usr/bin/env python3
"""
Script test điều khiển relay cho van điện tử và bơm
GPIO23 -> Van điện tử (Relay IN1/NO1)
GPIO24 -> Bơm (Relay IN2/NO2)

Lưu ý: Relay module thường hoạt động ở chế độ LOW trigger
- GPIO = LOW (0) -> Relay BẬT
- GPIO = HIGH (1) -> Relay TẮT
"""

import RPi.GPIO as GPIO
import time

# Cấu hình GPIO
VAN_PIN = 23    # GPIO23 -> Van điện tử
BOM_PIN = 24    # GPIO24 -> Bơm

def setup_gpio():
    """Khởi tạo GPIO"""
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)

    # Cấu hình các chân OUTPUT, mặc định HIGH (relay TẮT)
    GPIO.setup(VAN_PIN, GPIO.OUT, initial=GPIO.HIGH)
    GPIO.setup(BOM_PIN, GPIO.OUT, initial=GPIO.HIGH)

    print("✓ Đã khởi tạo GPIO")
    print(f"  - GPIO{VAN_PIN} (Van): OUTPUT")
    print(f"  - GPIO{BOM_PIN} (Bơm): OUTPUT")
    print()

def tat_tat_ca():
    """Tắt tất cả thiết bị (HIGH = relay ngắt)"""
    GPIO.output(VAN_PIN, GPIO.HIGH)
    GPIO.output(BOM_PIN, GPIO.HIGH)
    print("⦿ Đã tắt tất cả thiết bị\n")

def test_van():
    """Test điều khiển van điện tử"""
    print("=" * 50)
    print("TEST VAN ĐIỆN TỬ (GPIO23)")
    print("=" * 50)

    print("→ BẬT van...")
    GPIO.output(VAN_PIN, GPIO.LOW)  # LOW = BẬT
    time.sleep(3)

    print("→ TẮT van...")
    GPIO.output(VAN_PIN, GPIO.HIGH)  # HIGH = TẮT
    time.sleep(1)
    print("✓ Test van hoàn tất\n")

def test_bom():
    """Test điều khiển bơm"""
    print("=" * 50)
    print("TEST BƠM (GPIO24)")
    print("=" * 50)

    print("→ BẬT bơm...")
    GPIO.output(BOM_PIN, GPIO.LOW)  # LOW = BẬT
    time.sleep(3)

    print("→ TẮT bơm...")
    GPIO.output(BOM_PIN, GPIO.HIGH)  # HIGH = TẮT
    time.sleep(1)
    print("✓ Test bơm hoàn tất\n")

def test_dong_thoi():
    """Test bật đồng thời cả van và bơm"""
    print("=" * 50)
    print("TEST ĐỒNG THỜI VAN + BƠM")
    print("=" * 50)

    print("→ BẬT cả van và bơm...")
    GPIO.output(VAN_PIN, GPIO.LOW)
    GPIO.output(BOM_PIN, GPIO.LOW)
    time.sleep(3)

    print("→ TẮT cả van và bơm...")
    GPIO.output(VAN_PIN, GPIO.HIGH)
    GPIO.output(BOM_PIN, GPIO.HIGH)
    time.sleep(1)
    print("✓ Test đồng thời hoàn tất\n")

def test_luon_phien():
    """Test luân phiên van và bơm"""
    print("=" * 50)
    print("TEST LUÂN PHIÊN VAN <-> BƠM")
    print("=" * 50)

    for i in range(3):
        print(f"→ Lần {i+1}: BẬT van")
        GPIO.output(VAN_PIN, GPIO.LOW)
        time.sleep(1)
        GPIO.output(VAN_PIN, GPIO.HIGH)
        time.sleep(0.5)

        print(f"→ Lần {i+1}: BẬT bơm")
        GPIO.output(BOM_PIN, GPIO.LOW)
        time.sleep(1)
        GPIO.output(BOM_PIN, GPIO.HIGH)
        time.sleep(0.5)

    print("✓ Test luân phiên hoàn tất\n")

def menu_interactive():
    """Menu điều khiển tương tác"""
    print("\n" + "=" * 50)
    print("MENU ĐIỀU KHIỂN THỦ CÔNG")
    print("=" * 50)
    print("1. BẬT van")
    print("2. TẮT van")
    print("3. BẬT bơm")
    print("4. TẮT bơm")
    print("5. BẬT cả hai")
    print("6. TẮT cả hai")
    print("7. Kiểm tra trạng thái")
    print("0. Thoát")
    print("=" * 50)

    while True:
        try:
            choice = input("\nChọn chức năng (0-7): ").strip()

            if choice == "1":
                GPIO.output(VAN_PIN, GPIO.LOW)
                print("✓ Đã BẬT van")
            elif choice == "2":
                GPIO.output(VAN_PIN, GPIO.HIGH)
                print("✓ Đã TẮT van")
            elif choice == "3":
                GPIO.output(BOM_PIN, GPIO.LOW)
                print("✓ Đã BẬT bơm")
            elif choice == "4":
                GPIO.output(BOM_PIN, GPIO.HIGH)
                print("✓ Đã TẮT bơm")
            elif choice == "5":
                GPIO.output(VAN_PIN, GPIO.LOW)
                GPIO.output(BOM_PIN, GPIO.LOW)
                print("✓ Đã BẬT cả van và bơm")
            elif choice == "6":
                GPIO.output(VAN_PIN, GPIO.HIGH)
                GPIO.output(BOM_PIN, GPIO.HIGH)
                print("✓ Đã TẮT cả van và bơm")
            elif choice == "7":
                van_state = "BẬT" if GPIO.input(VAN_PIN) == GPIO.LOW else "TẮT"
                bom_state = "BẬT" if GPIO.input(BOM_PIN) == GPIO.LOW else "TẮT"
                print(f"  Van: {van_state}")
                print(f"  Bơm: {bom_state}")
            elif choice == "0":
                break
            else:
                print("Lựa chọn không hợp lệ!")

        except KeyboardInterrupt:
            break

def main():
    """Chương trình chính"""
    print("\n" + "=" * 50)
    print("SCRIPT TEST ĐIỀU KHIỂN RELAY")
    print("=" * 50 + "\n")

    try:
        # Khởi tạo GPIO
        setup_gpio()

        # Tắt tất cả trước khi bắt đầu
        tat_tat_ca()

        # Menu lựa chọn
        print("Chọn chế độ test:")
        print("1. Tự động test tất cả")
        print("2. Điều khiển thủ công")

        mode = input("\nChọn chế độ (1-2): ").strip()

        if mode == "1":
            # Test tự động
            input("\nNhấn Enter để test van điện tử...")
            test_van()

            input("Nhấn Enter để test bơm...")
            test_bom()

            input("Nhấn Enter để test đồng thời...")
            test_dong_thoi()

            input("Nhấn Enter để test luân phiên...")
            test_luon_phien()

            print("=" * 50)
            print("✓ HOÀN THÀNH TẤT CẢ CÁC TEST")
            print("=" * 50)

        elif mode == "2":
            # Điều khiển thủ công
            menu_interactive()

    except KeyboardInterrupt:
        print("\n\n⚠ Đã dừng bởi người dùng")
    except Exception as e:
        print(f"\n✗ Lỗi: {str(e)}")
    finally:
        # Tắt tất cả thiết bị trước khi thoát
        print("\n→ Tắt tất cả thiết bị...")
        tat_tat_ca()
        GPIO.cleanup()
        print("✓ Đã dọn dẹp GPIO\n")

if __name__ == "__main__":
    main()
