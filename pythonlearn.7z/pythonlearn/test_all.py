#!/usr/bin/env python3
"""
Script test tổng hợp toàn bộ hệ thống IoT kiểm soát mực nước
- Điều khiển van điện tử (GPIO23)
- Điều khiển bơm (GPIO24)
- Đọc cảm biến siêu âm (TRIG: GPIO27, ECHO: GPIO17)
"""

import RPi.GPIO as GPIO
import time
from datetime import datetime

# Cấu hình GPIO
VAN_PIN = 23
BOM_PIN = 24
TRIG_PIN = 27
ECHO_PIN = 17

# Hằng số
SOUND_SPEED = 34300
TIMEOUT = 0.1

def setup_gpio():
    """Khởi tạo tất cả GPIO"""
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)

    # Relay: OUTPUT, mặc định HIGH (TẮT)
    GPIO.setup(VAN_PIN, GPIO.OUT, initial=GPIO.HIGH)
    GPIO.setup(BOM_PIN, GPIO.OUT, initial=GPIO.HIGH)

    # Cảm biến: TRIG=OUTPUT, ECHO=INPUT
    GPIO.setup(TRIG_PIN, GPIO.OUT, initial=GPIO.LOW)
    GPIO.setup(ECHO_PIN, GPIO.IN)

    print("=" * 70)
    print("KHỞI TẠO HỆ THỐNG")
    print("=" * 70)
    print("✓ Relay:")
    print(f"  - GPIO{VAN_PIN} (Van điện tử): OUTPUT [TẮT]")
    print(f"  - GPIO{BOM_PIN} (Bơm): OUTPUT [TẮT]")
    print("✓ Cảm biến siêu âm:")
    print(f"  - GPIO{TRIG_PIN} (TRIG): OUTPUT")
    print(f"  - GPIO{ECHO_PIN} (ECHO): INPUT")
    print("=" * 70 + "\n")

    time.sleep(0.5)

def bat_van():
    """Bật van điện tử"""
    GPIO.output(VAN_PIN, GPIO.LOW)

def tat_van():
    """Tắt van điện tử"""
    GPIO.output(VAN_PIN, GPIO.HIGH)

def bat_bom():
    """Bật bơm"""
    GPIO.output(BOM_PIN, GPIO.LOW)

def tat_bom():
    """Tắt bơm"""
    GPIO.output(BOM_PIN, GPIO.HIGH)

def tat_tat_ca():
    """Tắt tất cả thiết bị"""
    tat_van()
    tat_bom()

def trang_thai_thiet_bi():
    """Lấy trạng thái hiện tại của thiết bị"""
    return {
        'van': GPIO.input(VAN_PIN) == GPIO.LOW,
        'bom': GPIO.input(BOM_PIN) == GPIO.LOW
    }

def do_khoang_cach():
    """Đo khoảng cách bằng cảm biến siêu âm"""
    GPIO.output(TRIG_PIN, GPIO.LOW)
    time.sleep(0.00002)

    GPIO.output(TRIG_PIN, GPIO.HIGH)
    time.sleep(0.00001)
    GPIO.output(TRIG_PIN, GPIO.LOW)

    # Chờ ECHO lên HIGH
    pulse_start = time.time()
    timeout_start = time.time()
    while GPIO.input(ECHO_PIN) == GPIO.LOW:
        pulse_start = time.time()
        if pulse_start - timeout_start > TIMEOUT:
            return -1

    # Chờ ECHO xuống LOW
    pulse_end = time.time()
    timeout_start = time.time()
    while GPIO.input(ECHO_PIN) == GPIO.HIGH:
        pulse_end = time.time()
        if pulse_end - timeout_start > TIMEOUT:
            return -1

    pulse_duration = pulse_end - pulse_start
    distance = (pulse_duration * SOUND_SPEED) / 2

    return round(distance, 2)

def do_nhieu_lan(so_lan=5):
    """Đo nhiều lần và lấy trung bình"""
    ket_qua = []
    for _ in range(so_lan):
        kc = do_khoang_cach()
        if kc > 0:
            ket_qua.append(kc)
        time.sleep(0.06)

    if len(ket_qua) == 0:
        return -1

    if len(ket_qua) >= 3:
        ket_qua.sort()
        ket_qua = ket_qua[1:-1]

    return round(sum(ket_qua) / len(ket_qua), 2)

def tinh_muc_nuoc(khoang_cach, chieu_cao_bon=100):
    """Tính mức nước"""
    if khoang_cach < 0:
        return None

    muc_nuoc = chieu_cao_bon - khoang_cach
    muc_nuoc = max(0, muc_nuoc)
    phan_tram = (muc_nuoc / chieu_cao_bon) * 100
    phan_tram = max(0, min(100, phan_tram))

    return {
        'khoang_cach': khoang_cach,
        'muc_nuoc': round(muc_nuoc, 2),
        'phan_tram': round(phan_tram, 1)
    }

def test_1_kiem_tra_toan_bo_phan_cung():
    """Test 1: Kiểm tra toàn bộ phần cứng"""
    print("\n" + "=" * 70)
    print("TEST 1: KIỂM TRA PHẦN CỨNG")
    print("=" * 70 + "\n")

    # Test relay
    print("→ Test relay van...")
    bat_van()
    time.sleep(1)
    print("  ✓ Van BẬT")
    tat_van()
    time.sleep(0.5)
    print("  ✓ Van TẮT")

    print("\n→ Test relay bơm...")
    bat_bom()
    time.sleep(1)
    print("  ✓ Bơm BẬT")
    tat_bom()
    time.sleep(0.5)
    print("  ✓ Bơm TẮT")

    # Test cảm biến
    print("\n→ Test cảm biến siêu âm (đo 5 lần)...")
    for i in range(5):
        kc = do_khoang_cach()
        if kc > 0:
            print(f"  Lần {i+1}: {kc:6.2f} cm ✓")
        else:
            print(f"  Lần {i+1}: LỖI ✗")
        time.sleep(0.5)

    print("\n✓ Test phần cứng hoàn tất!\n")

def test_2_do_muc_nuoc_dong_thoi_dieu_khien():
    """Test 2: Đo mức nước và điều khiển thiết bị đồng thời"""
    print("\n" + "=" * 70)
    print("TEST 2: ĐO MỰC NƯỚC VÀ ĐIỀU KHIỂN ĐỒNG THỜI")
    print("=" * 70 + "\n")

    chieu_cao = float(input("Nhập chiều cao bồn (cm) [mặc định: 100]: ") or "100")
    print(f"\n→ Đo mức nước với bồn {chieu_cao} cm...")
    print("→ Bấm Ctrl+C để dừng\n")

    try:
        while True:
            # Đo mức nước
            kc = do_nhieu_lan(3)
            info = tinh_muc_nuoc(kc, chieu_cao)

            # Lấy trạng thái thiết bị
            tt = trang_thai_thiet_bi()

            # Hiển thị
            if info:
                van_icon = "✓" if tt['van'] else "✗"
                bom_icon = "✓" if tt['bom'] else "✗"

                print(f"\r[{datetime.now().strftime('%H:%M:%S')}] "
                      f"KC: {info['khoang_cach']:6.2f}cm | "
                      f"MN: {info['muc_nuoc']:6.2f}cm | "
                      f"{info['phan_tram']:5.1f}% | "
                      f"Van:{van_icon} | Bơm:{bom_icon} ", end='', flush=True)
            else:
                print(f"\r[{datetime.now().strftime('%H:%M:%S')}] LỖI ĐO", end='', flush=True)

            time.sleep(1)

    except KeyboardInterrupt:
        print("\n\n✓ Đã dừng test\n")

def test_3_logic_tu_dong():
    """Test 3: Logic tự động điều khiển theo mức nước"""
    print("\n" + "=" * 70)
    print("TEST 3: LOGIC TỰ ĐỘNG ĐIỀU KHIỂN")
    print("=" * 70 + "\n")

    chieu_cao = float(input("Nhập chiều cao bồn (cm) [mặc định: 100]: ") or "100")
    muc_thap = float(input("Mức nước thấp (%) [mặc định: 20]: ") or "20")
    muc_cao = float(input("Mức nước cao (%) [mặc định: 80]: ") or "80")

    print(f"\n→ Logic:")
    print(f"  - Nếu mức nước < {muc_thap}%: BẬT van + bơm (bơm nước vào)")
    print(f"  - Nếu mức nước > {muc_cao}%: TẮT van + bơm")
    print(f"  - Nếu mức nước ở giữa: GIỮ NGUYÊN trạng thái")
    print("\n→ Bấm Ctrl+C để dừng\n")

    try:
        while True:
            # Đo mức nước
            kc = do_nhieu_lan(3)
            info = tinh_muc_nuoc(kc, chieu_cao)

            if info:
                phan_tram = info['phan_tram']
                hanh_dong = ""

                # Logic điều khiển
                if phan_tram < muc_thap:
                    # Mức nước thấp -> Bơm vào
                    bat_van()
                    bat_bom()
                    hanh_dong = "BẬT van + bơm (BƠM VÀO)"
                elif phan_tram > muc_cao:
                    # Mức nước cao -> Tắt
                    tat_van()
                    tat_bom()
                    hanh_dong = "TẮT van + bơm"
                else:
                    # Mức nước OK
                    hanh_dong = "GIỮ NGUYÊN"

                # Hiển thị
                tt = trang_thai_thiet_bi()
                van_status = "BẬT" if tt['van'] else "TẮT"
                bom_status = "BẬT" if tt['bom'] else "TẮT"

                print(f"\r[{datetime.now().strftime('%H:%M:%S')}] "
                      f"{phan_tram:5.1f}% | "
                      f"Van: {van_status:3s} | Bơm: {bom_status:3s} | "
                      f"{hanh_dong:30s}", end='', flush=True)
            else:
                print(f"\r[{datetime.now().strftime('%H:%M:%S')}] LỖI ĐO - GIỮ NGUYÊN", end='', flush=True)

            time.sleep(2)

    except KeyboardInterrupt:
        print("\n\n✓ Đã dừng test\n")
        tat_tat_ca()

def test_4_dieu_khien_thu_cong():
    """Test 4: Điều khiển thủ công kết hợp đọc cảm biến"""
    print("\n" + "=" * 70)
    print("TEST 4: ĐIỀU KHIỂN THỦ CÔNG + ĐỌC CẢM BIẾN")
    print("=" * 70 + "\n")

    chieu_cao = float(input("Nhập chiều cao bồn (cm) [mặc định: 100]: ") or "100")

    print("\nLệnh điều khiển:")
    print("  v+ : BẬT van      | v- : TẮT van")
    print("  b+ : BẬT bơm      | b- : TẮT bơm")
    print("  vb+: BẬT cả hai   | vb-: TẮT cả hai")
    print("  s  : Xem trạng thái")
    print("  q  : Thoát")
    print()

    while True:
        try:
            # Đo mức nước
            kc = do_nhieu_lan(3)
            info = tinh_muc_nuoc(kc, chieu_cao)
            tt = trang_thai_thiet_bi()

            # Hiển thị trạng thái
            if info:
                print(f"\n[Mức nước: {info['phan_tram']:5.1f}%] "
                      f"[Van: {'BẬT' if tt['van'] else 'TẮT'}] "
                      f"[Bơm: {'BẬT' if tt['bom'] else 'TẮT'}]")
            else:
                print(f"\n[LỖI ĐO] [Van: {'BẬT' if tt['van'] else 'TẮT'}] "
                      f"[Bơm: {'BẬT' if tt['bom'] else 'TẮT'}]")

            # Nhập lệnh
            cmd = input("Nhập lệnh: ").strip().lower()

            if cmd == "v+":
                bat_van()
                print("✓ Đã BẬT van")
            elif cmd == "v-":
                tat_van()
                print("✓ Đã TẮT van")
            elif cmd == "b+":
                bat_bom()
                print("✓ Đã BẬT bơm")
            elif cmd == "b-":
                tat_bom()
                print("✓ Đã TẮT bơm")
            elif cmd == "vb+":
                bat_van()
                bat_bom()
                print("✓ Đã BẬT cả van và bơm")
            elif cmd == "vb-":
                tat_tat_ca()
                print("✓ Đã TẮT cả van và bơm")
            elif cmd == "s":
                continue
            elif cmd == "q":
                break
            else:
                print("Lệnh không hợp lệ!")

        except KeyboardInterrupt:
            break

    print("\n✓ Đã thoát\n")

def main():
    """Chương trình chính"""
    print("\n" + "=" * 70)
    print("SCRIPT TEST TỔNG HỢP HỆ THỐNG IoT KIỂM SOÁT MỰC NƯỚC")
    print("=" * 70 + "\n")

    try:
        # Khởi tạo GPIO
        setup_gpio()

        # Menu
        while True:
            print("\nCHỌN CHƯƠNG TRÌNH TEST:")
            print("1. Test kiểm tra phần cứng")
            print("2. Test đo mức nước đồng thời điều khiển")
            print("3. Test logic tự động")
            print("4. Test điều khiển thủ công")
            print("0. Thoát")

            choice = input("\nChọn (0-4): ").strip()

            if choice == "1":
                test_1_kiem_tra_toan_bo_phan_cung()
            elif choice == "2":
                test_2_do_muc_nuoc_dong_thoi_dieu_khien()
            elif choice == "3":
                test_3_logic_tu_dong()
            elif choice == "4":
                test_4_dieu_khien_thu_cong()
            elif choice == "0":
                break
            else:
                print("Lựa chọn không hợp lệ!")

    except KeyboardInterrupt:
        print("\n\n⚠ Đã dừng bởi người dùng")
    except Exception as e:
        print(f"\n✗ Lỗi: {str(e)}")
    finally:
        print("\n→ Tắt tất cả thiết bị...")
        tat_tat_ca()
        GPIO.cleanup()
        print("✓ Đã dọn dẹp GPIO")
        print("\nCảm ơn đã sử dụng!\n")

if __name__ == "__main__":
    main()
