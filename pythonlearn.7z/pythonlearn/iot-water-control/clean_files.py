import os
import re

def clean_file(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        # Remove UTF-8 BOM if exists
        content = content.replace('\ufeff', '')
        
        # Replace non-ASCII characters in comments with spaces
        lines = content.split('\n')
        cleaned_lines = []
        for line in lines:
            # Keep code, clean comments
            if '"""' in line or "'''" in line or '#' in line:
                line = ''.join(c if ord(c) < 128 else ' ' for c in line)
            cleaned_lines.append(line)
        
        cleaned = '\n'.join(cleaned_lines)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(cleaned)
        print(f"Cleaned: {filepath}")
        return True
    except Exception as e:
        print(f"Error cleaning {filepath}: {e}")
        return False

# Clean all Python files
for root, dirs, files in os.walk('.'):
    for file in files:
        if file.endswith('.py') and not file.startswith('clean_'):
            filepath = os.path.join(root, file)
            clean_file(filepath)

print("\nDone!")
