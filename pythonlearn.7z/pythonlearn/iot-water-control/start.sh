#!/bin/bash

# IoT Water Control System - Auto Starter
# This script starts the system and displays the public access link

clear

echo "======================================================================"
echo "           IoT WATER CONTROL SYSTEM - AUTO STARTER"
echo "======================================================================"
echo ""

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Clean up old URL file
rm -f public_url.txt

# Stop any existing processes
echo "[1/4] Stopping existing processes..."
sudo pkill -f "python3 main.py" 2>/dev/null
sleep 2

# Start the system
echo "[2/4] Starting IoT Water Control System..."
sudo python3 main.py > /tmp/iot.log 2>&1 &
MAIN_PID=$!

echo "[3/4] Waiting for system to start..."
sleep 3

# Wait for public URL file to be created (max 30 seconds)
echo "[4/4] Waiting for public link to be generated..."
COUNTER=0
while [ ! -f "public_url.txt" ] && [ $COUNTER -lt 30 ]; do
    echo -n "."
    sleep 1
    COUNTER=$((COUNTER + 1))
done
echo ""

echo ""
echo "======================================================================"
echo "                    SYSTEM STARTED SUCCESSFULLY!"
echo "======================================================================"
echo ""

# Display system information
IP_ADDRESS=$(hostname -I | awk '{print $1}')
echo "Raspberry Pi IP: $IP_ADDRESS"
echo ""

# Display URLs
if [ -f "public_url.txt" ]; then
    echo "======================================================================"
    echo "                         ACCESS LINKS"
    echo "======================================================================"
    echo ""
    cat public_url.txt
    echo ""
    echo "======================================================================"
    echo ""

    # Extract and highlight the public URL
    PUBLIC_URL=$(grep "Public URL:" public_url.txt | cut -d' ' -f3)
    if [ ! -z "$PUBLIC_URL" ]; then
        echo ""
        echo "  >>> COPY THIS LINK FOR MOBILE ACCESS <<<"
        echo ""
        echo "      $PUBLIC_URL"
        echo ""
        echo "======================================================================"
    fi
else
    echo "Local URL: http://$IP_ADDRESS:7860"
    echo "API URL: http://$IP_ADDRESS:8000"
    echo ""
    echo "Note: Public link not available yet. Check /tmp/iot.log for details."
fi

echo ""
echo "System is running in background."
echo "API Server: http://$IP_ADDRESS:8000"
echo "Frontend: http://$IP_ADDRESS:7860"
echo ""
echo "To view logs: tail -f /tmp/iot.log"
echo "To stop: sudo pkill -f 'python3 main.py'"
echo ""
echo "======================================================================"
echo ""
