# IoT Water Control System - Quick Start Guide

## 🚀 3 Ways to Start the System

### Method 1: Smart Launcher (RECOMMENDED - Shows Public Link)
```bash
cd /home/nhamgiatuananh/Desktop/pythonlearn/iot-water-control
python3 start_with_url.py
```
✅ **Best option** - Automatically starts system and displays public link!

### Method 2: Simple Shell Script
```bash
cd /home/nhamgiatuananh/Desktop/pythonlearn/iot-water-control
./start.sh
```

### Method 3: Python Launcher
```bash
cd /home/nhamgiatuananh/Desktop/pythonlearn/iot-water-control
python3 launcher.py
```

---

## 📱 Get Public Access Link

After starting the system, the **public URL is automatically saved** to:
```bash
cat public_url.txt
```

Or run this utility anytime:
```bash
python3 get_public_url.py
```

---

## 🌐 Current System Information

**Your Raspberry Pi IP:** `192.168.1.10`

**Access URLs:**
- **Local Network:** http://192.168.1.10:7860
- **API Server:** http://192.168.1.10:8000
- **Public Link:** https://95f5df42c1d9baab0b.gradio.live

---

## 🔧 Useful Commands

### Start System
```bash
python3 start_with_url.py
```

### Stop System
```bash
sudo pkill -f "python3 main.py"
```

### View Logs
```bash
tail -f /tmp/iot.log
```

### Check Public URL
```bash
cat public_url.txt
# OR
python3 get_public_url.py
```

### Check System Status
```bash
curl http://localhost:8000/api/status | python3 -m json.tool
```

---

## 📲 Access from Mobile Phone

1. **Local Network** (same WiFi):
   - Open browser on phone
   - Go to: `http://192.168.1.10:7860`

2. **From Anywhere** (Internet):
   - Copy the public URL from `public_url.txt`:
     ```
     https://95f5df42c1d9baab0b.gradio.live
     ```
   - Paste into any browser on any device
   - Works from anywhere in the world!

---

## 📁 Project Structure

```
iot-water-control/
├── backend/              # Hardware control
│   ├── hardware.py      # GPIO relay control
│   └── sensor.py        # Ultrasonic sensor
├── api/                 # REST API
│   ├── models.py        # Data models
│   └── server.py        # FastAPI server
├── frontend/            # Web UI
│   └── app.py           # Gradio interface
├── main.py              # Main orchestrator
├── start_with_url.py    # Smart launcher (RECOMMENDED)
├── launcher.py          # Python launcher
├── start.sh             # Shell launcher
├── get_public_url.py    # URL utility
├── public_url.txt       # Auto-generated URLs
└── requirements.txt     # Dependencies
```

---

## 🎯 Features

✅ **Manual Control:** Turn valve and pump ON/OFF
✅ **Auto Mode:** Automatic water level control
✅ **Real-time Monitoring:** Live sensor readings
✅ **Mobile Access:** Access from anywhere via public link
✅ **Emergency Stop:** Quick safety shutdown
✅ **Statistics:** Track device on-time

---

## 💡 Tips

1. **Public URL Changes** each time you restart
   - Always check `public_url.txt` after restart
   - Run `python3 get_public_url.py` to get current link

2. **For Permanent Access**, consider:
   - Setting up port forwarding on your router
   - Using a dynamic DNS service
   - Or use Gradio share (regenerates each restart)

3. **Security**: The Gradio public link is temporary and random
   - Only people with the exact URL can access it
   - Changes on every restart

---

## 🐛 Troubleshooting

### System won't start?
```bash
# Stop all processes
sudo pkill -f "python3 main.py"
sudo pkill -f "python3.*api.server"
sudo pkill -f "python3.*frontend.app"

# Free ports
sudo lsof -i :7860 | grep -v COMMAND | awk '{print $2}' | xargs -r sudo kill -9
sudo lsof -i :8000 | grep -v COMMAND | awk '{print $2}' | xargs -r sudo kill -9

# Start again
python3 start_with_url.py
```

### Can't find public URL?
```bash
python3 get_public_url.py
```

### Check if running?
```bash
ps aux | grep "python3 main.py"
curl http://localhost:8000/
```

---

## 📞 Support

- View logs: `tail -f /tmp/iot.log`
- Check status: `curl http://localhost:8000/api/status`
- Get public URL: `cat public_url.txt`

---

**Last Updated:** November 18, 2025
**System Version:** 2.0
**Raspberry Pi IP:** 192.168.1.10
