"""
Gradio Frontend
Web interface for IoT water control system
"""

import gradio as gr
import requests
import time

# API endpoint
API_URL = "http://localhost:8000"


def get_status():
    """Get system status"""
    try:
        response = requests.get(f"{API_URL}/api/status", timeout=5)
        if response.status_code == 200:
            return response.json()
        return None
    except:
        return None


def control_device(device: str, action: str):
    """Control device"""
    try:
        response = requests.post(
            f"{API_URL}/api/control",
            json={"device": device, "action": action},
            timeout=5
        )
        return response.status_code == 200
    except:
        return False


def turn_off_all_devices():
    """Turn off all devices"""
    try:
        response = requests.post(f"{API_URL}/api/control/all/off", timeout=5)
        return response.status_code == 200
    except:
        return False


def set_auto_mode(enabled: bool, low: float, high: float):
    """Configure auto mode"""
    try:
        response = requests.post(
            f"{API_URL}/api/auto",
            json={
                "enabled": enabled,
                "low_threshold": low,
                "high_threshold": high
            },
            timeout=5
        )
        return response.status_code == 200
    except:
        return False


def set_tank_height(height: float):
    """Configure tank height"""
    try:
        response = requests.post(
            f"{API_URL}/api/tank/config",
            json={"height": height},
            timeout=5
        )
        return response.status_code == 200
    except:
        return False


def update_status():
    """Update status display"""
    status = get_status()

    if not status:
        return [
            "Error: No connection",
            "N/A",
            "N/A",
            "Offline",
            "Offline",
            "Offline",
            "N/A"
        ]

    # Sensor data
    sensor = status["sensor"]
    hardware = status["hardware"]

    water_pct = sensor["percentage"]
    distance = sensor["distance"]
    water_cm = sensor["water_level"]

    # Format displays
    water_level_text = f"Water Level: {water_pct:.1f}%"
    distance_text = f"Distance: {distance:.1f} cm"
    water_level_cm_text = f"Water: {water_cm:.1f} cm"

    # Device status
    van_state = "ON" if hardware["van"]["state"] else "OFF"
    bom_state = "ON" if hardware["bom"]["state"] else "OFF"

    # Auto mode
    auto_enabled = status["auto_config"]["enabled"]
    auto_text = f"Auto: ON ({status['auto_config']['low_threshold']:.0f}% - {status['auto_config']['high_threshold']:.0f}%)" if auto_enabled else "Auto: OFF"

    # Uptime
    uptime_sec = status["uptime"]
    hours = int(uptime_sec // 3600)
    minutes = int((uptime_sec % 3600) // 60)
    seconds = int(uptime_sec % 60)
    uptime_text = f"Uptime: {hours:02d}:{minutes:02d}:{seconds:02d}"

    return [
        water_level_text,
        distance_text,
        water_level_cm_text,
        f"Valve: {van_state}",
        f"Pump: {bom_state}",
        auto_text,
        uptime_text
    ]


# Control functions
def van_on_click():
    success = control_device("van", "on")
    time.sleep(0.3)
    return update_status() if success else update_status()


def van_off_click():
    success = control_device("van", "off")
    time.sleep(0.3)
    return update_status() if success else update_status()


def bom_on_click():
    success = control_device("bom", "on")
    time.sleep(0.3)
    return update_status() if success else update_status()


def bom_off_click():
    success = control_device("bom", "off")
    time.sleep(0.3)
    return update_status() if success else update_status()


def emergency_stop_click():
    success = turn_off_all_devices()
    time.sleep(0.3)
    return update_status() if success else update_status()


def auto_mode_toggle(enabled: bool, low: float, high: float):
    success = set_auto_mode(enabled, low, high)
    time.sleep(0.3)
    return update_status() if success else update_status()


def tank_config_submit(height: float):
    success = set_tank_height(height)
    return "Updated!" if success else "Error!"


def build_interface():
    """Build Gradio interface"""

    with gr.Blocks(title="IoT Water Control", theme=gr.themes.Soft()) as app:

        # Header
        gr.Markdown("# IoT Water Control System")
        gr.Markdown("Monitor and control water level with Raspberry Pi")

        # Main layout
        with gr.Row():
            # Left column - Status display
            with gr.Column(scale=1):
                gr.Markdown("### System Status")

                water_level = gr.Textbox(
                    label="Water Level",
                    value="Water Level: 0.0%",
                    interactive=False
                )

                with gr.Row():
                    distance_display = gr.Textbox(
                        label="Sensor Distance",
                        value="Distance: 0 cm",
                        interactive=False
                    )
                    water_level_cm = gr.Textbox(
                        label="Water Level (cm)",
                        value="Water: 0 cm",
                        interactive=False
                    )

                gr.Markdown("### Device Status")

                van_status = gr.Textbox(
                    label="Valve",
                    value="Valve: OFF",
                    interactive=False
                )

                bom_status = gr.Textbox(
                    label="Pump",
                    value="Pump: OFF",
                    interactive=False
                )

                auto_status = gr.Textbox(
                    label="Auto Mode",
                    value="Auto: OFF",
                    interactive=False
                )

                uptime_display = gr.Textbox(
                    label="System Uptime",
                    value="Uptime: 00:00:00",
                    interactive=False
                )

            # Right column - Controls
            with gr.Column(scale=1):
                gr.Markdown("### Device Control")

                # Valve controls
                gr.Markdown("#### Valve")
                with gr.Row():
                    van_on_btn = gr.Button("Turn ON Valve", variant="primary", size="lg")
                    van_off_btn = gr.Button("Turn OFF Valve", variant="secondary", size="lg")

                # Pump controls
                gr.Markdown("#### Pump")
                with gr.Row():
                    bom_on_btn = gr.Button("Turn ON Pump", variant="primary", size="lg")
                    bom_off_btn = gr.Button("Turn OFF Pump", variant="secondary", size="lg")

                # Emergency stop
                gr.Markdown("#### Emergency")
                emergency_btn = gr.Button(
                    "TURN OFF ALL",
                    variant="stop",
                    size="lg"
                )

                gr.Markdown("---")

                # Auto mode
                gr.Markdown("### Auto Mode")

                auto_enabled = gr.Checkbox(
                    label="Enable auto mode",
                    value=False
                )

                with gr.Row():
                    auto_low = gr.Slider(
                        minimum=0,
                        maximum=100,
                        value=20,
                        step=5,
                        label="Low threshold (%)"
                    )
                    auto_high = gr.Slider(
                        minimum=0,
                        maximum=100,
                        value=80,
                        step=5,
                        label="High threshold (%)"
                    )

                auto_apply_btn = gr.Button("Apply", variant="primary")

                gr.Markdown("---")

                # Tank config
                gr.Markdown("### Tank Configuration")

                tank_height_input = gr.Number(
                    label="Tank height (cm)",
                    value=100,
                    minimum=10,
                    maximum=500
                )

                tank_config_btn = gr.Button("Save Config", variant="secondary")
                tank_config_msg = gr.Textbox(
                    label="Message",
                    value="",
                    interactive=False
                )

        # Connect events
        outputs = [
            water_level, distance_display, water_level_cm,
            van_status, bom_status, auto_status, uptime_display
        ]

        van_on_btn.click(van_on_click, outputs=outputs)
        van_off_btn.click(van_off_click, outputs=outputs)
        bom_on_btn.click(bom_on_click, outputs=outputs)
        bom_off_btn.click(bom_off_click, outputs=outputs)
        emergency_btn.click(emergency_stop_click, outputs=outputs)

        auto_apply_btn.click(
            auto_mode_toggle,
            inputs=[auto_enabled, auto_low, auto_high],
            outputs=outputs
        )

        tank_config_btn.click(
            tank_config_submit,
            inputs=[tank_height_input],
            outputs=[tank_config_msg]
        )

        # Auto-refresh

        # Footer
        gr.Markdown("---")
        gr.Markdown("Powered by Raspberry Pi | FastAPI | Gradio")

    return app


def run_app(host: str = "0.0.0.0", port: int = 7860, share: bool = False):
    """Run Gradio app"""
    import os
    import threading
    app = build_interface()

    # Function to save URLs after launch
    def save_urls():
        import time
        time.sleep(5)  # Wait for Gradio to fully initialize

        try:
            # Get URLs from Gradio app
            local_url = f"http://{host if host != '0.0.0.0' else 'localhost'}:{port}"
            share_url = None

            # Try to get share URL from Gradio's internal state
            if hasattr(app, 'share_url') and app.share_url:
                share_url = app.share_url
            elif hasattr(app, 'server') and hasattr(app.server, 'share_url'):
                share_url = app.server.share_url

            # Save to file
            if share and share_url:
                urls_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), "public_url.txt")
                with open(urls_file, "w") as f:
                    f.write(f"Local URL: {local_url}\n")
                    f.write(f"Public URL: {share_url}\n")
                    f.write(f"\nAccess from anywhere using the Public URL above!\n")
                print(f"\n{'='*70}")
                print(f"  PUBLIC ACCESS LINK SAVED TO public_url.txt")
                print(f"{'='*70}")
                print(f"  {share_url}")
                print(f"{'='*70}\n")
        except Exception as e:
            print(f"Note: Could not save share URL: {e}")

    # Start URL saving in background thread
    if share:
        threading.Thread(target=save_urls, daemon=True).start()

    # Launch the app (this blocks)
    app.launch(
        server_name=host,
        server_port=port,
        share=share,
        show_error=True
    )


if __name__ == "__main__":
    run_app()
