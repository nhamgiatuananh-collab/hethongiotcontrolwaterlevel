"""
API Data Models
Pydantic models for request/response
"""

from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime


class DeviceControl(BaseModel):
    """Device control model"""
    device: str = Field(..., description="Device name: 'van' or 'bom'")
    action: str = Field(..., description="Action: 'on' or 'off'")


class AutoModeConfig(BaseModel):
    """Auto mode configuration"""
    enabled: bool = Field(..., description="Enable/disable auto mode")
    low_threshold: float = Field(20.0, ge=0, le=100, description="Low threshold (%)")
    high_threshold: float = Field(80.0, ge=0, le=100, description="High threshold (%)")


class TankConfig(BaseModel):
    """Tank configuration"""
    height: float = Field(..., gt=0, description="Tank height (cm)")


class DeviceStatus(BaseModel):
    """Device status"""
    state: bool
    pin: int
    total_on_time: float


class HardwareStatus(BaseModel):
    """Hardware status"""
    van: DeviceStatus
    bom: DeviceStatus
    auto_mode: bool
    timestamp: str


class SensorData(BaseModel):
    """Sensor data"""
    distance: float
    water_level: float
    percentage: float
    status: str
    timestamp: str


class SensorStatus(BaseModel):
    """Sensor status"""
    distance: float
    water_level: float
    percentage: float
    tank_height: float
    monitoring: bool
    history_size: int
    timestamp: str


class SystemStatus(BaseModel):
    """System status"""
    hardware: HardwareStatus
    sensor: SensorStatus
    uptime: float


class HistoryPoint(BaseModel):
    """History data point"""
    percentage: float
    timestamp: str


class ApiResponse(BaseModel):
    """Generic API response"""
    success: bool
    message: Optional[str] = None
    data: Optional[dict] = None
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())
