"""
FastAPI Server
REST API for IoT water control system
"""

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import asyncio
import sys
import os
import time
import json
from datetime import datetime
from typing import List

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.hardware import get_hardware_controller
from backend.sensor import get_sensor_reader
from api.models import (
    DeviceControl, AutoModeConfig, TankConfig, ApiResponse,
    SystemStatus, HardwareStatus, SensorStatus
)

app = FastAPI(
    title="IoT Water Control API",
    description="API for IoT water level control system",
    version="1.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global variables
hardware_controller = None
sensor_reader = None
start_time = time.time()
auto_controller_task = None
auto_config = {
    "enabled": False,
    "low_threshold": 20.0,
    "high_threshold": 80.0
}

# WebSocket connections
active_connections: List[WebSocket] = []


# ============== LIFECYCLE ==============

@app.on_event("startup")
async def startup_event():
    """Server startup"""
    global hardware_controller, sensor_reader, auto_controller_task

    print("[API] Starting API server...")

    # Initialize hardware
    hardware_controller = get_hardware_controller()

    # Initialize sensor
    sensor_reader = get_sensor_reader()
    sensor_reader.start_monitoring()

    # Start auto controller
    auto_controller_task = asyncio.create_task(auto_controller_loop())

    print("[API] API server ready!")


@app.on_event("shutdown")
async def shutdown_event():
    """Server shutdown"""
    print("[API] Shutting down...")

    if hardware_controller:
        hardware_controller.cleanup()

    if sensor_reader:
        sensor_reader.stop_monitoring()
        sensor_reader.cleanup()

    print("[API] Shutdown complete")


# ============== AUTO CONTROLLER ==============

async def auto_controller_loop():
    """Auto control loop"""
    print("[Auto] Starting auto controller...")

    while True:
        try:
            if auto_config["enabled"]:
                percentage = sensor_reader.water_percentage

                # Control logic
                if percentage < auto_config["low_threshold"]:
                    # Low water -> Turn on valve and pump
                    if not hardware_controller.van_state:
                        hardware_controller.turn_on_van()
                        print(f"[Auto] Turned on valve - Water: {percentage:.1f}%")

                    if not hardware_controller.bom_state:
                        hardware_controller.turn_on_bom()
                        print(f"[Auto] Turned on pump - Water: {percentage:.1f}%")

                elif percentage > auto_config["high_threshold"]:
                    # High water -> Turn off valve and pump
                    if hardware_controller.van_state:
                        hardware_controller.turn_off_van()
                        print(f"[Auto] Turned off valve - Water: {percentage:.1f}%")

                    if hardware_controller.bom_state:
                        hardware_controller.turn_off_bom()
                        print(f"[Auto] Turned off pump - Water: {percentage:.1f}%")

            await asyncio.sleep(2)  # Check every 2 seconds

        except Exception as e:
            print(f"[Auto] Error: {e}")
            await asyncio.sleep(5)


# ============== WEBSOCKET ==============

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket for realtime updates"""
    await websocket.accept()
    active_connections.append(websocket)
    print(f"[WS] Client connected. Total: {len(active_connections)}")

    try:
        while True:
            # Send status every second
            status = get_system_status()
            await websocket.send_json(status)
            await asyncio.sleep(1)

    except WebSocketDisconnect:
        active_connections.remove(websocket)
        print(f"[WS] Client disconnected. Total: {len(active_connections)}")
    except Exception as e:
        print(f"[WS] Error: {e}")
        if websocket in active_connections:
            active_connections.remove(websocket)


# ============== HELPER FUNCTIONS ==============

def get_system_status() -> dict:
    """Get full system status"""
    hardware_status = hardware_controller.get_status()
    sensor_status = sensor_reader.get_status()
    uptime = time.time() - start_time

    return {
        "hardware": hardware_status,
        "sensor": sensor_status,
        "auto_config": auto_config,
        "uptime": round(uptime, 2),
        "timestamp": datetime.now().isoformat()
    }


# ============== API ENDPOINTS ==============

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "name": "IoT Water Control API",
        "version": "1.0.0",
        "status": "running",
        "uptime": round(time.time() - start_time, 2)
    }


@app.get("/api/status")
async def get_status():
    """Get system status"""
    try:
        status = get_system_status()
        return JSONResponse(status)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/hardware/status")
async def get_hardware_status():
    """Get hardware status"""
    try:
        return JSONResponse(hardware_controller.get_status())
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/sensor/status")
async def get_sensor_status():
    """Get sensor status"""
    try:
        return JSONResponse(sensor_reader.get_status())
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/sensor/read")
async def read_sensor():
    """Read sensor immediately"""
    try:
        data = sensor_reader.read_sensor()
        return JSONResponse(data)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/sensor/history")
async def get_sensor_history(limit: int = 50):
    """Get measurement history"""
    try:
        history = sensor_reader.get_history(limit)
        return JSONResponse({"history": history, "count": len(history)})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/control")
async def control_device(control: DeviceControl):
    """Control device"""
    try:
        device = control.device.lower()
        action = control.action.lower()

        if device not in ["van", "bom"]:
            raise HTTPException(status_code=400, detail="Device must be 'van' or 'bom'")

        if action not in ["on", "off"]:
            raise HTTPException(status_code=400, detail="Action must be 'on' or 'off'")

        # Execute control
        if device == "van":
            result = hardware_controller.turn_on_van() if action == "on" else hardware_controller.turn_off_van()
        else:  # bom
            result = hardware_controller.turn_on_bom() if action == "on" else hardware_controller.turn_off_bom()

        return JSONResponse(result)

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/control/all/off")
async def turn_off_all():
    """Turn off all devices"""
    try:
        result = hardware_controller.turn_off_all()
        return JSONResponse(result)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/auto")
async def set_auto_mode(config: AutoModeConfig):
    """Configure auto mode"""
    try:
        # Validate thresholds
        if config.low_threshold >= config.high_threshold:
            raise HTTPException(
                status_code=400,
                detail="low_threshold must be less than high_threshold"
            )

        # Update config
        auto_config["enabled"] = config.enabled
        auto_config["low_threshold"] = config.low_threshold
        auto_config["high_threshold"] = config.high_threshold

        # Update hardware
        hardware_controller.set_auto_mode(config.enabled)

        return JSONResponse({
            "success": True,
            "auto_config": auto_config,
            "timestamp": datetime.now().isoformat()
        })

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/tank/config")
async def set_tank_config(config: TankConfig):
    """Configure tank height"""
    try:
        sensor_reader.set_tank_height(config.height)

        return JSONResponse({
            "success": True,
            "tank_height": config.height,
            "timestamp": datetime.now().isoformat()
        })

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============== RUN SERVER ==============

def run_server(host: str = "0.0.0.0", port: int = 8000):
    """Run API server"""
    import uvicorn
    uvicorn.run(app, host=host, port=port, log_level="info")


if __name__ == "__main__":
    run_server()
