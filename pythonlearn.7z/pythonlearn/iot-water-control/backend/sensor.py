"""
Backend Sensor Module
Read HC-SR04 ultrasonic sensor to measure water level
"""

import RPi.GPIO as GPIO
import time
import threading
from typing import Optional, List
from datetime import datetime
from collections import deque


class SensorReader:
    """Ultrasonic sensor reader"""

    def __init__(self, trig_pin: int = 27, echo_pin: int = 17, tank_height: float = 100.0):
        self.TRIG_PIN = trig_pin
        self.ECHO_PIN = echo_pin
        self.TANK_HEIGHT = tank_height  # Tank height in cm

        self._initialized = False
        self._lock = threading.Lock()
        self._running = False
        self._thread: Optional[threading.Thread] = None

        # Constants
        self.SOUND_SPEED = 34300  # cm/s
        self.TIMEOUT = 0.1  # 100ms

        # Data
        self.current_distance = 0.0
        self.water_level = 0.0
        self.water_percentage = 0.0
        self.history: deque = deque(maxlen=100)  # Store last 100 points

    def initialize(self):
        """Initialize GPIO"""
        if self._initialized:
            return

        with self._lock:
            GPIO.setmode(GPIO.BCM)
            GPIO.setwarnings(False)

            GPIO.setup(self.TRIG_PIN, GPIO.OUT, initial=GPIO.LOW)
            GPIO.setup(self.ECHO_PIN, GPIO.IN)

            self._initialized = True
            time.sleep(0.5)  # Wait for sensor to stabilize
            print(f"[Sensor] Initialized - TRIG: {self.TRIG_PIN}, ECHO: {self.ECHO_PIN}")

    def cleanup(self):
        """Cleanup"""
        self.stop_monitoring()
        if self._initialized:
            try:
                # Only cleanup if GPIO is still initialized
                GPIO.cleanup([self.TRIG_PIN, self.ECHO_PIN])
            except:
                pass
            self._initialized = False
            print("[Sensor] Cleaned up GPIO")

    def measure_distance(self) -> float:
        """
        Measure distance once
        Returns: Distance in cm or -1 if error
        """
        # Reset TRIG
        GPIO.output(self.TRIG_PIN, GPIO.LOW)
        time.sleep(0.00002)

        # Send 10us pulse
        GPIO.output(self.TRIG_PIN, GPIO.HIGH)
        time.sleep(0.00001)
        GPIO.output(self.TRIG_PIN, GPIO.LOW)

        # Wait for ECHO to go HIGH
        pulse_start = time.time()
        timeout_start = time.time()
        while GPIO.input(self.ECHO_PIN) == GPIO.LOW:
            pulse_start = time.time()
            if pulse_start - timeout_start > self.TIMEOUT:
                return -1

        # Wait for ECHO to go LOW
        pulse_end = time.time()
        timeout_start = time.time()
        while GPIO.input(self.ECHO_PIN) == GPIO.HIGH:
            pulse_end = time.time()
            if pulse_end - timeout_start > self.TIMEOUT:
                return -1

        # Calculate distance
        pulse_duration = pulse_end - pulse_start
        distance = (pulse_duration * self.SOUND_SPEED) / 2

        return round(distance, 2)

    def measure_average(self, samples: int = 5) -> float:
        """
        Measure multiple times and get average
        Args:
            samples: Number of measurements
        Returns: Average distance in cm
        """
        measurements: List[float] = []

        for _ in range(samples):
            dist = self.measure_distance()
            if dist > 0:
                measurements.append(dist)
            time.sleep(0.06)  # 60ms between measurements

        if len(measurements) == 0:
            return -1

        # Remove outliers if >= 3 measurements
        if len(measurements) >= 3:
            measurements.sort()
            measurements = measurements[1:-1]  # Remove min and max

        return round(sum(measurements) / len(measurements), 2)

    def calculate_water_level(self, distance: float) -> dict:
        """
        Calculate water level from measured distance
        Args:
            distance: Distance from sensor to water surface (cm)
        Returns: Dict containing water level info
        """
        if distance < 0:
            return {
                "distance": -1,
                "water_level": -1,
                "percentage": -1,
                "status": "ERROR",
                "timestamp": datetime.now().isoformat()
            }

        # Water level = tank height - distance
        water_level = self.TANK_HEIGHT - distance
        water_level = max(0, water_level)  # Not negative

        percentage = (water_level / self.TANK_HEIGHT) * 100
        percentage = max(0, min(100, percentage))  # 0-100%

        # Determine status
        if percentage >= 90:
            status = "FULL"
        elif percentage >= 70:
            status = "HIGH"
        elif percentage >= 40:
            status = "MEDIUM"
        elif percentage >= 20:
            status = "LOW"
        else:
            status = "VERY_LOW"

        return {
            "distance": round(distance, 2),
            "water_level": round(water_level, 2),
            "percentage": round(percentage, 1),
            "status": status,
            "timestamp": datetime.now().isoformat()
        }

    def read_sensor(self) -> dict:
        """Read sensor and calculate water level"""
        distance = self.measure_average(samples=3)
        result = self.calculate_water_level(distance)

        # Save to history
        self.history.append({
            "percentage": result["percentage"],
            "timestamp": result["timestamp"]
        })

        # Update current values
        self.current_distance = result["distance"]
        self.water_level = result["water_level"]
        self.water_percentage = result["percentage"]

        return result

    def _monitoring_loop(self):
        """Continuous sensor reading loop"""
        print("[Sensor] Started monitoring...")

        while self._running:
            try:
                self.read_sensor()
                time.sleep(2)  # Read every 2 seconds
            except Exception as e:
                print(f"[Sensor] Read error: {e}")
                time.sleep(5)

        print("[Sensor] Stopped monitoring")

    def start_monitoring(self):
        """Start automatic sensor reading"""
        if self._running:
            return

        self._running = True
        self._thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self._thread.start()
        print("[Sensor] Started monitoring thread")

    def stop_monitoring(self):
        """Stop sensor reading"""
        if not self._running:
            return

        self._running = False
        if self._thread:
            self._thread.join(timeout=5)
        print("[Sensor] Stopped monitoring thread")

    def get_status(self) -> dict:
        """Get current status"""
        return {
            "distance": self.current_distance,
            "water_level": self.water_level,
            "percentage": self.water_percentage,
            "tank_height": self.TANK_HEIGHT,
            "monitoring": self._running,
            "history_size": len(self.history),
            "timestamp": datetime.now().isoformat()
        }

    def get_history(self, limit: int = 50) -> List[dict]:
        """Get measurement history"""
        return list(self.history)[-limit:]

    def set_tank_height(self, height: float):
        """Set tank height"""
        self.TANK_HEIGHT = height
        print(f"[Sensor] Set tank height: {height} cm")


# Singleton instance
_sensor_reader = None


def get_sensor_reader() -> SensorReader:
    """Get singleton instance of SensorReader"""
    global _sensor_reader
    if _sensor_reader is None:
        _sensor_reader = SensorReader()
        _sensor_reader.initialize()
    return _sensor_reader
