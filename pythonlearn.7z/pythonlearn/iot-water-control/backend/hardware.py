"""
Backend Hardware Control Module
Control relay (valve and pump) via GPIO
"""

import RPi.GPIO as GPIO
import time
import threading
from typing import Optional
from datetime import datetime


class HardwareController:
    """Controller for valve and pump relays"""

    def __init__(self, van_pin: int = 23, bom_pin: int = 24):
        self.VAN_PIN = van_pin
        self.BOM_PIN = bom_pin
        self._initialized = False
        self._lock = threading.Lock()

        # State
        self.van_state = False
        self.bom_state = False
        self.auto_mode = False

        # Statistics
        self.van_on_time = 0.0
        self.bom_on_time = 0.0
        self.van_start_time: Optional[float] = None
        self.bom_start_time: Optional[float] = None

    def initialize(self):
        """Initialize GPIO"""
        if self._initialized:
            return

        with self._lock:
            GPIO.setmode(GPIO.BCM)
            GPIO.setwarnings(False)

            # Setup OUTPUT, default HIGH (OFF for relay)
            GPIO.setup(self.VAN_PIN, GPIO.OUT, initial=GPIO.HIGH)
            GPIO.setup(self.BOM_PIN, GPIO.OUT, initial=GPIO.HIGH)

            self._initialized = True
            print(f"[Hardware] Initialized GPIO - Valve: {self.VAN_PIN}, Pump: {self.BOM_PIN}")

    def cleanup(self):
        """Cleanup GPIO"""
        if self._initialized:
            self.turn_off_all()
            GPIO.cleanup()
            self._initialized = False
            print("[Hardware] Cleaned up GPIO")

    def turn_on_van(self) -> dict:
        """Turn on valve"""
        with self._lock:
            GPIO.output(self.VAN_PIN, GPIO.LOW)
            self.van_state = True
            self.van_start_time = time.time()

            return {
                "success": True,
                "device": "van",
                "state": True,
                "timestamp": datetime.now().isoformat()
            }

    def turn_off_van(self) -> dict:
        """Turn off valve"""
        with self._lock:
            GPIO.output(self.VAN_PIN, GPIO.HIGH)
            self.van_state = False

            # Update on time
            if self.van_start_time:
                self.van_on_time += time.time() - self.van_start_time
                self.van_start_time = None

            return {
                "success": True,
                "device": "van",
                "state": False,
                "timestamp": datetime.now().isoformat()
            }

    def turn_on_bom(self) -> dict:
        """Turn on pump"""
        with self._lock:
            GPIO.output(self.BOM_PIN, GPIO.LOW)
            self.bom_state = True
            self.bom_start_time = time.time()

            return {
                "success": True,
                "device": "bom",
                "state": True,
                "timestamp": datetime.now().isoformat()
            }

    def turn_off_bom(self) -> dict:
        """Turn off pump"""
        with self._lock:
            GPIO.output(self.BOM_PIN, GPIO.HIGH)
            self.bom_state = False

            # Update on time
            if self.bom_start_time:
                self.bom_on_time += time.time() - self.bom_start_time
                self.bom_start_time = None

            return {
                "success": True,
                "device": "bom",
                "state": False,
                "timestamp": datetime.now().isoformat()
            }

    def turn_off_all(self) -> dict:
        """Turn off all devices"""
        self.turn_off_van()
        self.turn_off_bom()
        return {
            "success": True,
            "message": "All devices turned off",
            "timestamp": datetime.now().isoformat()
        }

    def get_status(self) -> dict:
        """Get current status"""
        # Calculate current on time
        current_van_time = self.van_on_time
        current_bom_time = self.bom_on_time

        if self.van_state and self.van_start_time:
            current_van_time += time.time() - self.van_start_time

        if self.bom_state and self.bom_start_time:
            current_bom_time += time.time() - self.bom_start_time

        return {
            "van": {
                "state": self.van_state,
                "pin": self.VAN_PIN,
                "total_on_time": round(current_van_time, 2)
            },
            "bom": {
                "state": self.bom_state,
                "pin": self.BOM_PIN,
                "total_on_time": round(current_bom_time, 2)
            },
            "auto_mode": self.auto_mode,
            "timestamp": datetime.now().isoformat()
        }

    def set_auto_mode(self, enabled: bool):
        """Enable/disable auto mode"""
        self.auto_mode = enabled
        return {
            "success": True,
            "auto_mode": self.auto_mode,
            "timestamp": datetime.now().isoformat()
        }


# Singleton instance
_hardware_controller = None


def get_hardware_controller() -> HardwareController:
    """Get singleton instance of HardwareController"""
    global _hardware_controller
    if _hardware_controller is None:
        _hardware_controller = HardwareController()
        _hardware_controller.initialize()
    return _hardware_controller
