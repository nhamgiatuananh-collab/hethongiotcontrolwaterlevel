#!/usr/bin/env python3
"""
IoT Water Control System - Main Entry Point
Start all services: Backend + API + Frontend
"""

import multiprocessing
import sys
import os
import time
import signal

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

class ProcessManager:
    def __init__(self):
        self.processes = []
        self.running = False

    def start_api_server(self):
        print("Starting API server...")
        from api.server import run_server
        process = multiprocessing.Process(target=run_server, args=("0.0.0.0", 8000), name="API")
        process.start()
        self.processes.append(process)
        print("API server started at http://0.0.0.0:8000")

    def start_frontend(self):
        print("Starting Frontend with public link...")
        from frontend.app import run_app
        process = multiprocessing.Process(target=run_app, args=("0.0.0.0", 7860, True), name="Frontend")
        process.start()
        self.processes.append(process)
        print("Frontend started - Public link will be shown")

    def start_all(self):
        print("\n" + "="*70)
        print("IoT WATER CONTROL SYSTEM")
        print("="*70 + "\n")

        try:
            self.start_api_server()
            time.sleep(3)
            self.start_frontend()
            time.sleep(2)
            self.running = True

            print("\n" + "="*70)
            print("SYSTEM STARTED!")
            print("="*70)
            print("\nLocal:  http://localhost:7860")
            print("API:    http://localhost:8000")
            print("\nPress Ctrl+C to stop\n")
            print("="*70 + "\n")

            self.wait_for_exit()

        except KeyboardInterrupt:
            print("\n\nStopping...")
            self.stop_all()
        except Exception as e:
            print(f"\nError: {e}")
            self.stop_all()

    def wait_for_exit(self):
        try:
            while self.running:
                for proc in self.processes:
                    if not proc.is_alive():
                        print(f"Process {proc.name} stopped!")
                        self.running = False
                        break
                time.sleep(1)
        except KeyboardInterrupt:
            pass

    def stop_all(self):
        print("\nStopping all services...")
        for proc in self.processes:
            if proc.is_alive():
                print(f"  Stopping {proc.name}...")
                proc.terminate()
                proc.join(timeout=5)
                if proc.is_alive():
                    print(f"  Force kill {proc.name}...")
                    proc.kill()
                    proc.join()
        print("All services stopped\n")

def signal_handler(signum, frame):
    print("\n\nReceived stop signal...")
    sys.exit(0)

def main():
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    manager = ProcessManager()
    try:
        manager.start_all()
    except KeyboardInterrupt:
        print("\n\nStopping...")
    except Exception as e:
        print(f"\nError: {e}")
    finally:
        manager.stop_all()

if __name__ == "__main__":
    multiprocessing.set_start_method('spawn', force=True)
    main()
