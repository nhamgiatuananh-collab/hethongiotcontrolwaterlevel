# 🌊 IoT Water Control System

Hệ thống IoT kiểm soát mực nước tự động với Raspberry Pi, FastAPI và Gradio.

## 📋 Tính năng

### ✅ Phần cứng
- Điều khiển van điện tử (GPIO23)
- Điều khiển bơm nước (GPIO24)
- Đọc cảm biến siêu âm HC-SR04 (TRIG: GPIO27, ECHO: GPIO17)

### ✅ Phần mềm
- **Backend**: Điều khiển GPIO, đọc cảm biến
- **API Server**: FastAPI với REST API + WebSocket
- **Frontend**: Giao diện web đẹp với Gradio
- **Auto Mode**: Tự động điều khiển theo mực nước

### ✅ Tính năng nổi bật
- 🎨 Giao diện đẹp, responsive
- ⚡ Real-time monitoring (cập nhật mỗi 2 giây)
- 🤖 Chế độ tự động thông minh
- 📊 Hiển thị biểu đồ, lịch sử
- 🚨 Nút dừng khẩn cấp
- ⚙️ Cấu hình linh hoạt

## 🔧 Cài đặt

### 1. Clone hoặc copy project

### 2. Cài đặt dependencies
```bash
cd iot-water-control
sudo pip3 install -r requirements.txt
```

### 3. Kết nối phần cứng
- GPIO23 → Relay IN1 (Van điện tử)
- GPIO24 → Relay IN2 (Bơm)
- GPIO27 → HC-SR04 TRIG
- GPIO17 → HC-SR04 ECHO

## 🚀 Chạy hệ thống

### Chạy toàn bộ (khuyến nghị)
```bash
sudo python3 main.py
```

### Hoặc chạy riêng từng service

**Chỉ API Server:**
```bash
sudo python3 -c "from api.server import run_server; run_server()"
```

**Chỉ Frontend:**
```bash
python3 -c "from frontend.app import run_app; run_app()"
```

## 📡 Truy cập

- **Frontend**: http://localhost:7860
- **API Server**: http://localhost:8000
- **API Docs**: http://localhost:8000/docs

## 🎮 Sử dụng

### Qua Web UI (Gradio)
1. Mở http://localhost:7860
2. Xem trạng thái mực nước real-time
3. Điều khiển van/bơm bằng nút bấm
4. Cấu hình chế độ tự động
5. Đặt chiều cao bồn

### Qua API
```bash
# Lấy trạng thái
curl http://localhost:8000/api/status

# Bật van
curl -X POST http://localhost:8000/api/control \
  -H "Content-Type: application/json" \
  -d '{"device": "van", "action": "on"}'

# Tắt bơm
curl -X POST http://localhost:8000/api/control \
  -H "Content-Type: application/json" \
  -d '{"device": "bom", "action": "off"}'

# Bật chế độ tự động
curl -X POST http://localhost:8000/api/auto \
  -H "Content-Type: application/json" \
  -d '{"enabled": true, "low_threshold": 20, "high_threshold": 80}'
```

## 📁 Cấu trúc project

```
iot-water-control/
├── main.py              # Entry point - khởi động toàn bộ
├── requirements.txt     # Python dependencies
├── README.md           # Tài liệu này
│
├── backend/            # Backend logic
│   ├── hardware.py     # Điều khiển GPIO
│   └── sensor.py       # Đọc cảm biến
│
├── api/                # API Server
│   ├── server.py       # FastAPI server
│   └── models.py       # Pydantic models
│
└── frontend/           # Frontend
    └── app.py          # Gradio UI
```

## ⚙️ Cấu hình

### Thay đổi GPIO pins
Sửa trong `backend/hardware.py` và `backend/sensor.py`:
```python
VAN_PIN = 23    # Thay đổi pin van
BOM_PIN = 24    # Thay đổi pin bơm
TRIG_PIN = 27   # Thay đổi pin TRIG
ECHO_PIN = 17   # Thay đổi pin ECHO
```

### Thay đổi ports
Sửa trong `main.py`:
```python
self.start_api_server()  # Port 8000
self.start_frontend()    # Port 7860
```

## 🐛 Troubleshooting

### Lỗi GPIO
```bash
# Đảm bảo chạy với sudo
sudo python3 main.py

# Kiểm tra GPIO
gpio readall
```

### Lỗi cài đặt
```bash
# Cập nhật pip
sudo pip3 install --upgrade pip

# Cài lại dependencies
sudo pip3 install -r requirements.txt --force-reinstall
```

### Port đã được sử dụng
```bash
# Kill process đang dùng port 8000
sudo fuser -k 8000/tcp

# Kill process đang dùng port 7860
sudo fuser -k 7860/tcp
```

## 📝 Ghi chú

- Relay hoạt động ở chế độ LOW trigger (LOW = BẬT, HIGH = TẮT)
- Cảm biến đo mỗi 2 giây
- Chế độ tự động kiểm tra mỗi 2 giây
- Frontend auto-refresh mỗi 2 giây

## 🚀 Phát triển tiếp

- [ ] Thêm database (SQLite/PostgreSQL) lưu lịch sử
- [ ] Thêm authentication (login/password)
- [ ] Tích hợp AWS IoT Core / MQTT
- [ ] Thêm notification (Email, Telegram)
- [ ] Thêm biểu đồ thời gian thực
- [ ] Mobile app (React Native)

## 📄 License

MIT License - Sử dụng tự do cho mục đích cá nhân và thương mại.

