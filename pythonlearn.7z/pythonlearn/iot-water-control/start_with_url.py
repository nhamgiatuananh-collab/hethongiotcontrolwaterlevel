#!/usr/bin/env python3
"""
IoT Water Control System - Launcher with URL Display
Starts the system and captures/displays the Gradio public share URL
"""

import subprocess
import threading
import time
import re
import os
import signal
import sys


class SystemLauncher:
    def __init__(self):
        self.processes = []
        self.share_url = None
        self.local_url = None
        self.running = False

    def print_header(self):
        print("\n" + "="*70)
        print(" "*15 + "IoT WATER CONTROL SYSTEM")
        print(" "*20 + "Smart Launcher v2.0")
        print("="*70 + "\n")

    def stop_existing(self):
        """Stop any existing processes"""
        print("[1/4] Stopping existing processes...")
        try:
            subprocess.run(["sudo", "pkill", "-f", "python3 main.py"],
                          stderr=subprocess.DEVNULL)
            time.sleep(2)
            print("  ✓ Cleanup complete\n")
        except:
            print("  ✓ No existing processes\n")

    def start_api(self):
        """Start API server"""
        print("[2/4] Starting API server...")

        script_dir = os.path.dirname(os.path.abspath(__file__))

        # Start API in background
        process = subprocess.Popen(
            ["sudo", "python3", "-c",
             "import sys; sys.path.append('%s'); from api.server import run_server; run_server('0.0.0.0', 8000)" % script_dir],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT
        )

        self.processes.append(("API", process))

        # Wait for API to start
        time.sleep(3)

        # Check if it's running
        try:
            result = subprocess.run(["curl", "-s", "http://localhost:8000/"],
                                   capture_output=True, timeout=3)
            if result.returncode == 0:
                print("  ✓ API server ready at http://0.0.0.0:8000\n")
                return True
        except:
            pass

        print("  ⚠ API server may not be ready\n")
        return False

    def monitor_output(self, process, name):
        """Monitor process output and extract URLs"""
        try:
            for line in iter(process.stdout.readline, b''):
                try:
                    decoded = line.decode('utf-8').strip()

                    # Look for Gradio URLs
                    if 'Running on local URL' in decoded or 'http://127.0.0.1' in decoded or 'http://0.0.0.0' in decoded:
                        match = re.search(r'(http://[^\s]+)', decoded)
                        if match and not self.local_url:
                            self.local_url = match.group(1)
                            print(f"\n✓ Local URL: {self.local_url}")

                    if 'Running on public URL' in decoded or 'gradio.live' in decoded:
                        match = re.search(r'(https://[a-zA-Z0-9]+\.gradio\.live)', decoded)
                        if match:
                            self.share_url = match.group(1)
                            print(f"✓ Public URL: {self.share_url}\n")

                            # Save to file
                            self.save_urls()

                    # Print gradio output
                    if 'gradio' in decoded.lower() or 'Running on' in decoded:
                        print(f"  [{name}] {decoded}")

                except:
                    pass
        except:
            pass

    def start_frontend(self):
        """Start frontend with output monitoring"""
        print("[3/4] Starting Gradio frontend with public share...")
        print("  (This may take 30-60 seconds)\n")

        script_dir = os.path.dirname(os.path.abspath(__file__))

        # Start frontend
        process = subprocess.Popen(
            ["sudo", "python3", "-c",
             "import sys; sys.path.append('%s'); from frontend.app import run_app; run_app('0.0.0.0', 7860, True)" % script_dir],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,
            universal_newlines=False
        )

        self.processes.append(("Frontend", process))

        # Start monitoring thread
        monitor_thread = threading.Thread(
            target=self.monitor_output,
            args=(process, "Gradio"),
            daemon=True
        )
        monitor_thread.start()

        # Wait for URLs
        print("[4/4] Waiting for Gradio to generate URLs...")
        for i in range(60):
            if self.share_url:
                break

            if i > 0 and i % 10 == 0:
                print(f"  ... still waiting ({i}s)")

            time.sleep(1)

        return self.share_url is not None

    def save_urls(self):
        """Save URLs to file"""
        if self.share_url or self.local_url:
            script_dir = os.path.dirname(os.path.abspath(__file__))
            url_file = os.path.join(script_dir, "public_url.txt")

            with open(url_file, "w") as f:
                if self.local_url:
                    f.write(f"Local URL: {self.local_url}\n")
                if self.share_url:
                    f.write(f"Public URL: {self.share_url}\n")
                    f.write(f"\nAccess from anywhere using the Public URL!\n")

    def display_results(self):
        """Display final results"""
        import socket
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
        except:
            ip = "localhost"

        print("\n" + "="*70)
        print(" "*20 + "SYSTEM STARTED SUCCESSFULLY!")
        print("="*70 + "\n")

        print(f"Raspberry Pi IP: {ip}\n")

        print("="*70)
        print(" "*25 + "ACCESS LINKS")
        print("="*70 + "\n")

        print(f"Local Network:  http://{ip}:7860")
        print(f"API Server:     http://{ip}:8000\n")

        if self.share_url:
            print(f"Public Access:  {self.share_url}\n")
            print("="*70)
            print("\n" + " "*10 + ">>> COPY THIS LINK FOR MOBILE ACCESS <<<")
            print("\n" + " "*15 + f"{self.share_url}\n")
            print("="*70)
        else:
            print("Note: Public URL not captured yet.")
            print("Run: python3 get_public_url.py\n")

        print("\n" + "="*70)
        print("System is running. Press Ctrl+C to stop.")
        print("="*70 + "\n")

    def wait_for_exit(self):
        """Wait for user to stop"""
        try:
            while True:
                # Check if processes are still running
                all_alive = all(proc[1].poll() is None for proc in self.processes)
                if not all_alive:
                    print("\nWarning: Some processes have stopped!")
                    break
                time.sleep(2)
        except KeyboardInterrupt:
            pass

    def stop_all(self):
        """Stop all processes"""
        print("\n\nStopping all services...")

        for name, proc in self.processes:
            if proc.poll() is None:
                print(f"  Stopping {name}...")
                proc.terminate()

                try:
                    proc.wait(timeout=5)
                except:
                    print(f"  Force killing {name}...")
                    proc.kill()

        # Also clean up via pkill
        subprocess.run(["sudo", "pkill", "-f", "python3.*api.server"],
                      stderr=subprocess.DEVNULL)
        subprocess.run(["sudo", "pkill", "-f", "python3.*frontend.app"],
                      stderr=subprocess.DEVNULL)

        print("All services stopped.\n")

    def run(self):
        """Main run method"""
        try:
            self.print_header()
            self.stop_existing()
            self.start_api()
            self.start_frontend()
            self.display_results()
            self.wait_for_exit()
        except KeyboardInterrupt:
            print("\n\nStopping...")
        except Exception as e:
            print(f"\n\nError: {e}")
        finally:
            self.stop_all()


def main():
    launcher = SystemLauncher()
    launcher.run()


if __name__ == "__main__":
    main()
