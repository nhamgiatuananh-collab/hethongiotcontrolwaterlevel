#!/usr/bin/env python3
"""
IoT Water Control System - Smart Launcher
Starts the system and displays the public access link prominently
"""

import os
import sys
import time
import subprocess
import socket


def print_header():
    """Print welcome header"""
    print("\n" + "=" * 70)
    print(" " * 15 + "IoT WATER CONTROL SYSTEM")
    print(" " * 20 + "Smart Launcher v1.0")
    print("=" * 70 + "\n")


def get_ip_address():
    """Get local IP address"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "Unknown"


def stop_existing_processes():
    """Stop any running instances"""
    print("[Step 1/5] Stopping existing processes...")
    try:
        subprocess.run(["sudo", "pkill", "-f", "python3 main.py"],
                      stderr=subprocess.DEVNULL)
        time.sleep(2)
        print("  ✓ Cleanup complete")
    except:
        print("  ✓ No existing processes found")


def cleanup_old_files():
    """Remove old URL file"""
    print("[Step 2/5] Cleaning up old data...")
    script_dir = os.path.dirname(os.path.abspath(__file__))
    url_file = os.path.join(script_dir, "public_url.txt")

    if os.path.exists(url_file):
        os.remove(url_file)

    print("  ✓ Ready to start")


def start_system():
    """Start the main system"""
    print("[Step 3/5] Starting IoT Water Control System...")
    script_dir = os.path.dirname(os.path.abspath(__file__))

    # Start main.py in background
    log_file = "/tmp/iot.log"
    with open(log_file, "w") as f:
        subprocess.Popen(
            ["sudo", "python3", "main.py"],
            cwd=script_dir,
            stdout=f,
            stderr=subprocess.STDOUT
        )

    time.sleep(3)
    print("  ✓ System started")


def wait_for_api():
    """Wait for API to be ready"""
    print("[Step 4/5] Waiting for API server...")

    for i in range(30):
        try:
            result = subprocess.run(
                ["curl", "-s", "http://localhost:8000/"],
                capture_output=True,
                timeout=2
            )
            if result.returncode == 0:
                print("  ✓ API server is ready")
                return True
        except:
            pass

        time.sleep(1)

    print("  ⚠ API server not responding (check /tmp/iot.log)")
    return False


def wait_for_public_url():
    """Wait for public URL to be generated"""
    print("[Step 5/5] Waiting for public link to be generated...")
    script_dir = os.path.dirname(os.path.abspath(__file__))
    url_file = os.path.join(script_dir, "public_url.txt")

    for i in range(60):
        if os.path.exists(url_file):
            time.sleep(1)  # Give it a moment to finish writing
            print("  ✓ Public link generated!")
            return url_file

        if i % 5 == 0 and i > 0:
            print(f"  ... still waiting ({i}s)")

        time.sleep(1)

    print("  ⚠ Public link not generated yet (may take a moment)")
    return None


def display_results(url_file):
    """Display access information"""
    print("\n" + "=" * 70)
    print(" " * 20 + "SYSTEM STARTED SUCCESSFULLY!")
    print("=" * 70 + "\n")

    # Get IP
    ip = get_ip_address()
    print(f"Raspberry Pi IP: {ip}\n")

    # Display URLs
    if url_file and os.path.exists(url_file):
        print("=" * 70)
        print(" " * 25 + "ACCESS LINKS")
        print("=" * 70 + "\n")

        with open(url_file, "r") as f:
            content = f.read()
            print(content)

        # Extract and highlight public URL
        for line in content.split("\n"):
            if "Public URL:" in line:
                public_url = line.split("Public URL:")[-1].strip()
                if public_url:
                    print("=" * 70)
                    print("\n" + " " * 10 + ">>> COPY THIS LINK FOR MOBILE ACCESS <<<")
                    print("\n" + " " * 15 + f"{public_url}\n")
                    print("=" * 70)
                break
    else:
        print(f"Local Access: http://{ip}:7860")
        print(f"API Access: http://{ip}:8000")
        print("\nNote: Public link will appear when Gradio tunnel is ready.")
        print("Check: cat public_url.txt (once created)")

    print("\n" + "=" * 70)
    print("SYSTEM INFORMATION")
    print("=" * 70)
    print(f"API Server:  http://{ip}:8000")
    print(f"Frontend:    http://{ip}:7860")
    print(f"Log File:    /tmp/iot.log")
    print("\nUSEFUL COMMANDS:")
    print("  View logs:  tail -f /tmp/iot.log")
    print("  Check URL:  cat public_url.txt")
    print("  Stop:       sudo pkill -f 'python3 main.py'")
    print("=" * 70 + "\n")


def main():
    """Main launcher function"""
    try:
        print_header()
        stop_existing_processes()
        cleanup_old_files()
        start_system()
        wait_for_api()
        url_file = wait_for_public_url()
        display_results(url_file)

        print("System is now running in the background.")
        print("You can safely close this window.\n")

    except KeyboardInterrupt:
        print("\n\nLauncher interrupted by user.")
        sys.exit(0)
    except Exception as e:
        print(f"\n\nError: {e}")
        print("Check /tmp/iot.log for details.")
        sys.exit(1)


if __name__ == "__main__":
    main()
