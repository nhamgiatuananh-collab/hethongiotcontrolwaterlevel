#!/usr/bin/env python3
"""
Script debug cảm biến siêu âm HC-SR04
Kiểm tra xem lỗi ở code hay phần cứng
"""

import RPi.GPIO as GPIO
import time

# GPIO pins
TRIG_PIN = 27
ECHO_PIN = 17

# Tốc độ âm thanh
SOUND_SPEED_CM_S = 34300  # cm/s
SOUND_SPEED_CM_US = 0.034  # cm/µs

def setup():
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)
    GPIO.setup(TRIG_PIN, GPIO.OUT, initial=GPIO.LOW)
    GPIO.setup(ECHO_PIN, GPIO.IN)
    time.sleep(0.5)
    print("✓ GPIO khởi tạo xong\n")

def do_va_debug():
    """Đo và hiển thị chi tiết để debug"""

    # Reset TRIG
    GPIO.output(TRIG_PIN, GPIO.LOW)
    time.sleep(0.00002)

    # Phát xung 10µs
    GPIO.output(TRIG_PIN, GPIO.HIGH)
    time.sleep(0.00001)  # 10µs
    GPIO.output(TRIG_PIN, GPIO.LOW)

    # Đợi ECHO lên HIGH
    timeout = time.time() + 0.1
    while GPIO.input(ECHO_PIN) == GPIO.LOW:
        pulse_start = time.time()
        if time.time() > timeout:
            return None

    # Đợi ECHO xuống LOW
    timeout = time.time() + 0.1
    while GPIO.input(ECHO_PIN) == GPIO.HIGH:
        pulse_end = time.time()
        if time.time() > timeout:
            return None

    # Tính toán chi tiết
    pulse_duration_s = pulse_end - pulse_start  # giây
    pulse_duration_ms = pulse_duration_s * 1000  # mili giây
    pulse_duration_us = pulse_duration_s * 1000000  # micro giây

    # Thử nhiều cách tính
    distance_1 = (pulse_duration_s * SOUND_SPEED_CM_S) / 2
    distance_2 = (pulse_duration_us * SOUND_SPEED_CM_US) / 2
    distance_3 = pulse_duration_us / 58  # Công thức phổ biến
    distance_4 = pulse_duration_us / 29 / 2  # Công thức khác

    return {
        'pulse_s': pulse_duration_s,
        'pulse_ms': pulse_duration_ms,
        'pulse_us': pulse_duration_us,
        'dist_1': distance_1,
        'dist_2': distance_2,
        'dist_3': distance_3,
        'dist_4': distance_4
    }

def main():
    print("=" * 70)
    print("DEBUG CẢM BIẾN SIÊU ÂM HC-SR04")
    print("=" * 70)
    print("\nMục đích: Tìm nguyên nhân đo sai khoảng cách\n")

    setup()

    print("Hướng dẫn:")
    print("1. Đặt vật cản (tay, sách, v.v.) trước cảm biến")
    print("2. Đo khoảng cách thực tế bằng thước")
    print("3. So sánh với kết quả đo")
    print("\n" + "=" * 70 + "\n")

    lan_do = 0

    try:
        while True:
            lan_do += 1

            if lan_do > 1:
                input(f"\nLần {lan_do}: Nhấn Enter để đo (hoặc Ctrl+C để thoát)...")
            else:
                input(f"Lần {lan_do}: Nhấn Enter để bắt đầu đo...")

            print(f"\n{'─' * 70}")
            print(f"ĐO LẦN {lan_do}")
            print(f"{'─' * 70}")

            # Đo 5 lần để lấy trung bình
            ket_qua = []
            for i in range(5):
                data = do_va_debug()
                if data:
                    ket_qua.append(data)
                time.sleep(0.06)

            if len(ket_qua) == 0:
                print("✗ LỖI: Không đo được (timeout)")
                continue

            # Tính trung bình
            avg = {
                'pulse_s': sum(r['pulse_s'] for r in ket_qua) / len(ket_qua),
                'pulse_ms': sum(r['pulse_ms'] for r in ket_qua) / len(ket_qua),
                'pulse_us': sum(r['pulse_us'] for r in ket_qua) / len(ket_qua),
                'dist_1': sum(r['dist_1'] for r in ket_qua) / len(ket_qua),
                'dist_2': sum(r['dist_2'] for r in ket_qua) / len(ket_qua),
                'dist_3': sum(r['dist_3'] for r in ket_qua) / len(ket_qua),
                'dist_4': sum(r['dist_4'] for r in ket_qua) / len(ket_qua),
            }

            # Hiển thị kết quả chi tiết
            print(f"\n📊 THỜI GIAN XUNG ECHO (trung bình {len(ket_qua)} lần đo):")
            print(f"   • Giây (s):        {avg['pulse_s']:.9f} s")
            print(f"   • Mili giây (ms):  {avg['pulse_ms']:.6f} ms")
            print(f"   • Micro giây (µs): {avg['pulse_us']:.2f} µs")

            print(f"\n📏 KHOẢNG CÁCH TÍNH THEO CÁC CÔNG THỨC:")
            print(f"   1. (time_s × 34300 cm/s) ÷ 2     = {avg['dist_1']:7.2f} cm")
            print(f"   2. (time_µs × 0.034 cm/µs) ÷ 2   = {avg['dist_2']:7.2f} cm")
            print(f"   3. time_µs ÷ 58                   = {avg['dist_3']:7.2f} cm")
            print(f"   4. time_µs ÷ 29 ÷ 2               = {avg['dist_4']:7.2f} cm")

            print(f"\n❓ Khoảng cách THỰC TẾ bạn đo được là bao nhiêu cm?")
            try:
                thuc_te = float(input("   Nhập khoảng cách thực (cm): "))

                print(f"\n📈 SO SÁNH VỚI THỰC TẾ ({thuc_te:.1f} cm):")
                for i, (label, dist) in enumerate([
                    ("Công thức 1", avg['dist_1']),
                    ("Công thức 2", avg['dist_2']),
                    ("Công thức 3", avg['dist_3']),
                    ("Công thức 4", avg['dist_4'])
                ], 1):
                    sai_so = abs(dist - thuc_te)
                    phan_tram = (sai_so / thuc_te * 100) if thuc_te > 0 else 0
                    icon = "✓" if sai_so < 2 else "✗"
                    print(f"   {icon} {label}: {dist:7.2f} cm | "
                          f"Sai số: {sai_so:6.2f} cm ({phan_tram:5.1f}%)")

            except ValueError:
                print("   (Bỏ qua so sánh)")

            print(f"\n{'─' * 70}")

    except KeyboardInterrupt:
        print("\n")
    finally:
        GPIO.cleanup()
        print("\n✓ Đã dọn dẹp GPIO")
        print("\n💡 KẾT LUẬN:")
        print("   • Nếu TẤT CẢ công thức đều sai → Cảm biến hư hoặc đấu nối sai")
        print("   • Nếu có 1 công thức ĐÚNG → Sửa code dùng công thức đó")
        print("   • Nếu kết quả dao động lớn → Nhiễu hoặc cảm biến không ổn định")
        print()

if __name__ == "__main__":
    main()
