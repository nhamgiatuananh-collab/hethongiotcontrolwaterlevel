#!/usr/bin/env python3
"""
Script test cảm biến siêu âm HC-SR04 để đo mực nước
GPIO27 -> TRIG (phát xung)
GPIO17 -> ECHO (nhận tín hiệu phản hồi)

Nguyên lý hoạt động:
1. TRIG phát xung 10μs
2. Cảm biến phát sóng siêu âm
3. ECHO nhận tín hiệu phản hồi
4. Tính khoảng cách = (thời gian * tốc độ âm thanh) / 2
"""

import RPi.GPIO as GPIO
import time

# Cấu hình GPIO
TRIG_PIN = 27   # GPIO27 -> TRIG
ECHO_PIN = 17   # GPIO17 -> ECHO

# Hằng số
SOUND_SPEED = 34300  # Tốc độ âm thanh: 343 m/s = 34300 cm/s
TIMEOUT = 0.1        # Timeout 100ms (khoảng cách tối đa ~17m)

def setup_gpio():
    """Khởi tạo GPIO"""
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)

    # TRIG: OUTPUT (phát xung)
    # ECHO: INPUT (nhận tín hiệu)
    GPIO.setup(TRIG_PIN, GPIO.OUT, initial=GPIO.LOW)
    GPIO.setup(ECHO_PIN, GPIO.IN)

    print("✓ Đã khởi tạo GPIO")
    print(f"  - GPIO{TRIG_PIN} (TRIG): OUTPUT")
    print(f"  - GPIO{ECHO_PIN} (ECHO): INPUT")
    print()

    # Chờ cảm biến ổn định
    time.sleep(0.5)

def do_khoang_cach():
    """
    Đo khoảng cách bằng cảm biến siêu âm
    Returns:
        float: Khoảng cách tính bằng cm, hoặc -1 nếu lỗi
    """
    # Đảm bảo TRIG ở mức LOW
    GPIO.output(TRIG_PIN, GPIO.LOW)
    time.sleep(0.00002)  # 20μs

    # Phát xung TRIG 10μs
    GPIO.output(TRIG_PIN, GPIO.HIGH)
    time.sleep(0.00001)  # 10μs
    GPIO.output(TRIG_PIN, GPIO.LOW)

    # Chờ ECHO lên HIGH
    pulse_start = time.time()
    timeout_start = time.time()
    while GPIO.input(ECHO_PIN) == GPIO.LOW:
        pulse_start = time.time()
        if pulse_start - timeout_start > TIMEOUT:
            return -1

    # Chờ ECHO xuống LOW
    pulse_end = time.time()
    timeout_start = time.time()
    while GPIO.input(ECHO_PIN) == GPIO.HIGH:
        pulse_end = time.time()
        if pulse_end - timeout_start > TIMEOUT:
            return -1

    # Tính khoảng cách
    pulse_duration = pulse_end - pulse_start
    distance = (pulse_duration * SOUND_SPEED) / 2

    return round(distance, 2)

def do_nhieu_lan(so_lan=5):
    """
    Đo nhiều lần và lấy trung bình
    Args:
        so_lan: Số lần đo
    Returns:
        float: Khoảng cách trung bình
    """
    ket_qua = []

    for i in range(so_lan):
        khoang_cach = do_khoang_cach()
        if khoang_cach > 0:
            ket_qua.append(khoang_cach)
        time.sleep(0.06)  # Chờ 60ms giữa các lần đo

    if len(ket_qua) == 0:
        return -1

    # Loại bỏ giá trị ngoại lai (outliers)
    if len(ket_qua) >= 3:
        ket_qua.sort()
        ket_qua = ket_qua[1:-1]  # Bỏ min và max

    return round(sum(ket_qua) / len(ket_qua), 2)

def tinh_muc_nuoc(khoang_cach, chieu_cao_bon=100):
    """
    Tính mức nước dựa trên khoảng cách đo được
    Args:
        khoang_cach: Khoảng cách từ cảm biến đến mặt nước (cm)
        chieu_cao_bon: Chiều cao bồn chứa (cm)
    Returns:
        dict: Thông tin mức nước
    """
    if khoang_cach < 0:
        return {
            'muc_nuoc_cm': -1,
            'phan_tram': -1,
            'trang_thai': 'LỖI ĐO'
        }

    # Mức nước = chiều cao bồn - khoảng cách
    muc_nuoc = chieu_cao_bon - khoang_cach
    phan_tram = (muc_nuoc / chieu_cao_bon) * 100

    # Đảm bảo không âm
    muc_nuoc = max(0, muc_nuoc)
    phan_tram = max(0, min(100, phan_tram))

    # Xác định trạng thái
    if phan_tram >= 80:
        trang_thai = "ĐẦY"
    elif phan_tram >= 50:
        trang_thai = "TRUNG BÌNH"
    elif phan_tram >= 20:
        trang_thai = "THẤP"
    else:
        trang_thai = "RẤT THẤP"

    return {
        'khoang_cach_cm': khoang_cach,
        'muc_nuoc_cm': round(muc_nuoc, 2),
        'phan_tram': round(phan_tram, 1),
        'trang_thai': trang_thai
    }

def hien_thi_thanh_tien_trinh(phan_tram):
    """Hiển thị thanh tiến trình mức nước"""
    do_rong = 30
    filled = int((phan_tram / 100) * do_rong)
    bar = '█' * filled + '░' * (do_rong - filled)

    # Màu sắc theo mức
    if phan_tram >= 80:
        color = "🟦"  # Xanh dương
    elif phan_tram >= 50:
        color = "🟩"  # Xanh lá
    elif phan_tram >= 20:
        color = "🟨"  # Vàng
    else:
        color = "🟥"  # Đỏ

    return f"{color} |{bar}| {phan_tram:.1f}%"

def test_don_gian():
    """Test đo đơn giản"""
    print("=" * 60)
    print("TEST ĐO ĐƠN GIẢN")
    print("=" * 60)

    for i in range(10):
        khoang_cach = do_khoang_cach()
        if khoang_cach > 0:
            print(f"Lần {i+1}: {khoang_cach:6.2f} cm")
        else:
            print(f"Lần {i+1}: LỖI ĐO")
        time.sleep(0.5)

    print("✓ Test hoàn tất\n")

def test_do_muc_nuoc(chieu_cao_bon=100):
    """Test đo mức nước với chiều cao bồn tùy chỉnh"""
    print("=" * 60)
    print(f"TEST ĐO MỰC NƯỚC (Chiều cao bồn: {chieu_cao_bon} cm)")
    print("=" * 60 + "\n")

    while True:
        # Đo nhiều lần để lấy giá trị chính xác
        khoang_cach = do_nhieu_lan(5)

        # Tính mức nước
        thong_tin = tinh_muc_nuoc(khoang_cach, chieu_cao_bon)

        if thong_tin['phan_tram'] >= 0:
            print(f"\r{'':60}", end='')  # Xóa dòng cũ
            print(f"\rKhoảng cách: {thong_tin['khoang_cach_cm']:6.2f} cm | "
                  f"Mức nước: {thong_tin['muc_nuoc_cm']:6.2f} cm | "
                  f"{hien_thi_thanh_tien_trinh(thong_tin['phan_tram'])} | "
                  f"{thong_tin['trang_thai']}", end='', flush=True)
        else:
            print(f"\r{'':60}", end='')
            print(f"\r⚠ LỖI ĐO", end='', flush=True)

        time.sleep(1)

def test_tinh_toan_logic():
    """Test logic tính toán mức nước với các giá trị mẫu"""
    print("=" * 60)
    print("TEST LOGIC TÍNH TOÁN")
    print("=" * 60)

    chieu_cao_bon = 100  # cm
    cac_khoang_cach = [5, 10, 20, 30, 50, 70, 80, 90, 95]

    print(f"Chiều cao bồn: {chieu_cao_bon} cm\n")
    print(f"{'Khoảng cách':^15} | {'Mức nước':^15} | {'%':^6} | {'Trạng thái':^15}")
    print("-" * 60)

    for kc in cac_khoang_cach:
        info = tinh_muc_nuoc(kc, chieu_cao_bon)
        print(f"{info['khoang_cach_cm']:^15.1f} | "
              f"{info['muc_nuoc_cm']:^15.1f} | "
              f"{info['phan_tram']:^6.1f} | "
              f"{info['trang_thai']:^15}")

    print("\n✓ Test hoàn tất\n")

def main():
    """Chương trình chính"""
    print("\n" + "=" * 60)
    print("SCRIPT TEST CẢM BIẾN SIÊU ÂM HC-SR04")
    print("=" * 60 + "\n")

    try:
        # Khởi tạo GPIO
        setup_gpio()

        # Menu
        print("Chọn chế độ test:")
        print("1. Test đo đơn giản (10 lần)")
        print("2. Test đo mức nước liên tục")
        print("3. Test logic tính toán")
        print("4. Test tùy chỉnh chiều cao bồn")

        mode = input("\nChọn chế độ (1-4): ").strip()

        if mode == "1":
            test_don_gian()

        elif mode == "2":
            print("\n→ Đo mức nước liên tục (Ctrl+C để dừng)\n")
            test_do_muc_nuoc()

        elif mode == "3":
            test_tinh_toan_logic()

        elif mode == "4":
            chieu_cao = float(input("Nhập chiều cao bồn (cm): "))
            print(f"\n→ Đo mức nước với bồn {chieu_cao} cm (Ctrl+C để dừng)\n")
            test_do_muc_nuoc(chieu_cao)

        else:
            print("Lựa chọn không hợp lệ!")

    except KeyboardInterrupt:
        print("\n\n⚠ Đã dừng bởi người dùng")
    except ValueError:
        print("\n✗ Giá trị nhập vào không hợp lệ!")
    except Exception as e:
        print(f"\n✗ Lỗi: {str(e)}")
    finally:
        GPIO.cleanup()
        print("\n✓ Đã dọn dẹp GPIO\n")

if __name__ == "__main__":
    main()
